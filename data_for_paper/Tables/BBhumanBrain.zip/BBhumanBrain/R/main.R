residuals = ComputeLogMeasureResiduals(feature_name, subject_data, brain_volume)
multiple_hypothesis_analysis = BrainFeatureAnalysis(residuals)
