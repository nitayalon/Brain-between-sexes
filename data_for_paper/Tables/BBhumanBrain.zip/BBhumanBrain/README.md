# biobank_data_analysis
This is the code used for Joel et al. (2020)
